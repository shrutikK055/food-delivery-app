import React, { useState } from 'react';
import { View, Text, FlatList, StyleSheet } from 'react-native';
import FoodItem from '../components/FoodItem';

const sampleData = [
  { id: '1', name: 'Pizza', price: 12 },
  { id: '2', name: 'Burger', price: 8 },
  { id: '3', name: 'Pasta', price: 10 },
];

export default function HomeScreen() {
  const [foods] = useState(sampleData);

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Menu</Text>
      <FlatList
        data={foods}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => <FoodItem food={item} />}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 10 },
  heading: { fontSize: 24, fontWeight: 'bold', marginBottom: 10 },
});