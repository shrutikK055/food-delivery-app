import React from 'react';
import { View, Text } from 'react-native';

export default function OrderScreen() {
  return (
    <View>
      <Text>Orders Screen (Work in Progress)</Text>
    </View>
  );
}