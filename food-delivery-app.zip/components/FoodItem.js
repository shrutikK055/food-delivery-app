import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';

export default function FoodItem({ food }) {
  const handleAddToCart = () => {
    alert(`Added ${food.name} to cart!`);
  };

  return (
    <View style={styles.item}>
      <Text style={styles.name}>{food.name}</Text>
      <Text style={styles.price}>${food.price}</Text>
      <Button title="Add to Cart" onPress={handleAddToCart} />
    </View>
  );
}

const styles = StyleSheet.create({
  item: { marginBottom: 15, padding: 15, backgroundColor: '#f2f2f2', borderRadius: 10 },
  name: { fontSize: 18, fontWeight: 'bold' },
  price: { marginBottom: 5 },
});